<?php

class DateType {
    
    public static $EVENT = "EVENT";
    public static $SETTLEMENT = "SETTLEMENT";
}
