<?php

class Period {
    
    public static $DAY = "DAY";
    public static $WEEK ="WEEK";
    public static $MONTH = "MONTH";
    public static $YEAR ="YEAR";
    
    
}
