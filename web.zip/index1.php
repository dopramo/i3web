<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"  lang="en-gb"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"  lang="en-gb"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"  lang="en-gb"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en-gb"> <!--<![endif]-->
    

<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
		<link rel="alternate" href="http://www.ngslanka.com/" hreflang="en-lk" />
		<link rel="alternate" href="http://www.ngslanka.com/" hreflang="en-sg" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="google-site-verification" content="dER87Dy-YgzRK5VZ3vjNnKC8_NkFb49438QrVksWR-E" />
		<meta name="p:domain_verify" content="e4ef6941dec3211078bda4ffce25d08c"/>
          <base  />
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="generator" content="Joomla! - Open Source Content Management" />
  <title>Next Generation Services </title>
  <link href="index-2.html" rel="canonical" />
  <link href="indexc0d0.php?format=feed&amp;type=rss" rel="alternate" type="application/rss+xml" title="RSS 2.0" />
  <link href="index7b17.php?format=feed&amp;type=atom" rel="alternate" type="application/atom+xml" title="Atom 1.0" />
  <link href="ngs/templates/lt_corporation_onepage/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
  <link rel="stylesheet" href="ngs/templates/lt_corporation_onepage/css/bootstrap.min.css" type="text/css" />
  <link rel="stylesheet" href="ngs/templates/lt_corporation_onepage/css/bootstrap-responsive.min.css" type="text/css" />
  <link rel="stylesheet" href="ngs/plugins/system/helix/css/font-awesome.css" type="text/css" />
  <link rel="stylesheet" href="ngs/templates/lt_corporation_onepage/css/mobile-menu.css" type="text/css" />
  <link rel="stylesheet" href="ngs/templates/lt_corporation_onepage/css/template.css" type="text/css" />
  <link rel="stylesheet" href="ngs/templates/lt_corporation_onepage/css/presets/preset1.css" type="text/css" />
  <link rel="stylesheet" href="ngs/modules/mod_bt_googlemaps/tmpl/css/style.css" type="text/css" />
  <link rel="stylesheet" href="ngs/modules/mod_sp_quickcontact/assets/css/style.css" type="text/css" />
  <link rel="stylesheet" href="ngs/modules/mod_favslider/theme/css/favslider.css" type="text/css" />
  <style type="text/css">
.container{max-width:1170px}
#sp-main-body-wrapper{background: rgba(246, 180, 74, 0) !important; }

#sp-main-body-wrapper{background: rgba(246, 180, 74, 0) !important; }

#sp-footer-wrapper{padding: 30px 0 !important; }

  </style>
  <script src="ngs/media/jui/js/jquery.min.js" type="text/javascript"></script>
  <script src="ngs/media/jui/js/jquery-noconflict.js" type="text/javascript"></script>
  <script src="ngs/media/jui/js/jquery-migrate.min.js" type="text/javascript"></script>
  <script src="ngs/plugins/system/helix/js/jquery-noconflict.js" type="text/javascript"></script>
  <script src="ngs/media/jui/js/bootstrap.min.js" type="text/javascript"></script>
  <script src="ngs/plugins/system/helix/js/modernizr-2.6.2.min.js" type="text/javascript"></script>
  <script src="ngs/plugins/system/helix/js/helix.core.js" type="text/javascript"></script>
  <script src="ngs/plugins/system/helix/js/menu.js" type="text/javascript"></script>
  <script src="ngs/templates/lt_corporation_onepage/js/fixed-menu.js" type="text/javascript"></script>
  <script src="ngs/templates/lt_corporation_onepage/js/scroll.js" type="text/javascript"></script>
  <script src="http://maps.google.com/maps/api/js?sensor=true&amp;language=en-GB" type="text/javascript"></script>
  <script src="ngs/templates/mod_bt_googlemaps/tmpl/js/btbase64.min.js" type="text/javascript"></script>
  <script src="ngs/templates/mod_bt_googlemaps/tmpl/js/default.js" type="text/javascript"></script>
  <script src="ngs/templates/mod_sp_quickcontact/assets/js/script.js" type="text/javascript"></script>
  <script src="ngs/modules/mod_favslider/theme/js/jquery.flexslider.js" type="text/javascript"></script>
  <script src="ngs/modules/mod_favslider/theme/js/jquery.mousewheel.js" type="text/javascript"></script>
  <script src="ngs/modules/mod_favslider/theme/js/jquery.fitvids.js" type="text/javascript"></script>
  <script src="ngs/modules/mod_favslider/theme/js/favslider.js" type="text/javascript"></script>
  <script src="ngs/modules/mod_favslider/theme/js/viewportchecker/viewportchecker.js" type="text/javascript"></script>
  <script type="text/javascript">
spnoConflict(function($){

					function mainmenu() {
						$('.sp-menu').spmenu({
							startLevel: 0,
							direction: 'ltr',
							initOffset: {
								x: 0,
								y: 0
							},
							subOffset: {
								x: 0,
								y: 0
							},
							center: 0
						});
			}

			mainmenu();

			$(window).on('resize',function(){
				mainmenu();
			});


			});
  </script>
  <style type="text/css">
.container-lahiru {
  max-width: 750px;
  margin: 100px auto;
}

.silver-lahiru {
  float: left;
  width: 250px;
  height: 315px;
  background: rgba(153, 204, 237, 1);
  text-align: center;
  border-radius: 5px;
}

.plat-lahiru {
  float: left;
  width: 250px;
  height: 315px;
  background: rgba(250, 209, 209, 1);
  text-align: center;
  border-radius: 5px;
}

.gold-lahiru {
  float: left;
  position: relative;
  width: 250px;
  top: -30px;
  Bottom: -30px;
  padding: 50px 0;
  background: rgba(183, 255, 168, 1);
  text-align: center;
  border-radius: 5px;
  
  & > .price-lahiru {
    background: rgba(255,255,255,1);
    color: rgba(0,0,0,.7);
  }

  & > h1, & > h2, & > p, & > span {
    color: rgba(255,255,255,1);
  }
}





span-lahiru {
  margin-bottom: 20px;
  padding-bottom: 10px;
  display: inline-block;
  width: 125px;
  font-size: 1em;
  font-weight: 700;
  letter-spacing: 1px;
  color: rgba(0,0,0,.5);
  border-bottom: 1px solid rgba(0,0,0,.1);
}

.price-lahiru {
  height: 100px;
  width: 100px;
  text-align: center;
  background-color: rgba(87, 89, 124, 1);
  border-radius: 50%;
  line-height: 100px;
  color: #fff;
  font-size: 1.5em;
  font-weight: 100;
  margin: 20px auto;
}


</style>

            
</head>
    <body  class="featured homepage  ltr preset1 menu-home responsive bg hfeed clearfix">
	<!-- Google Tag Manager -->
<noscript><iframe src="http://www.googletagmanager.com/ns.html?id=GTM-MTKMP5"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'../../www.googletagmanager.com/gtm5445.html?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-MTKMP5');</script>
<!-- End Google Tag Manager -->
		<div class="body-innerwrapper">
            
            
<div style="display: block;z-index: 888;right: 300px;  position: absolute;">
<a href="careers/index.html" class="menu-item last" >
<span class="menu">|
<span class="menu-title" style="font-size: 11px;">CAREERS</span>
|</span></a></div>
            
        <!--[if lt IE 8]>
        <div class="chromeframe alert alert-danger" style="text-align:center">You are using an <strong>outdated</strong> browser. Please <a target="_blank" href="http://browsehappy.com/">upgrade your browser</a> or <a target="_blank" href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</div>
        <![endif]-->
        <section id="sp-menu-wrapper" 
                class=" "><div class="container"><div class="row-fluid" id="menu">
<div id="sp-logo" class="span3 visible-phone visible-tablet visible-desktop"><div class="logo-wrapper"><a href="http://www.ngslanka.com/ngs"><img alt="" class="image-logo" src="ngs/images/logo/logo.png" /></a></div></div>

<div id="sp-menu" class="span9 visible-phone visible-tablet visible-desktop">	


			<div id="sp-main-menu" class="visible-desktop">
				<ul class="sp-menu level-0"><li class="menu-item active first home"><a href="index.html" class="menu-item active first home" ><span class="menu"><span class="menu-title">Home</span><span class="menu-desc">Next Generation Services </span></span></a></li><li class="menu-item"><a href="#sp-slideshow-wrapper" class="menu-item" ><span class="menu"><span class="menu-title">Home</span></span></a></li><li class="menu-item"><a href="#sp-users-wrapper" class="menu-item" ><span class="menu"><span class="menu-title">About Us</span></span></a></li><li class="menu-item"><a href="#sp-main-body-wrapper" class="menu-item" ><span class="menu"><span class="menu-title">Our Services</span></span></a></li><li class="menu-item"><a href="#sp-testimonial-wrapper" class="menu-item" ><span class="menu"><span class="menu-title">Join Us</span></span></a></li><li class="menu-item"><a href="#sp-bottom-wrapper" class="menu-item" ><span class="menu"><span class="menu-title">Contact</span></span></a></li><li class="menu-item last"><a href="#sp-clients-wrapper" class="menu-item last" ><span class="menu"><span class="menu-title">Login</span></span></a></li></ul>        
			</div>  				
			</div>
</div></div></section><section id="sp-slideshow-wrapper" 
                class=" visible-phone visible-tablet visible-desktop"><div class="row-fluid" id="slideshow">
<div id="sp-slide" class="span12 visible-phone visible-tablet visible-desktop"><div class="module ">	
	<div class="mod-wrapper-flat clearfix">		
				

<script type="text/javascript">
  jQuery(document).ready(function() {

    jQuery('#slider-13299 .layout-effect').addClass("favhide").viewportCheckerfavslider({
      classToAdd: 'favshow layout-effect7', // Class to add to the elements when they are visible
      offset: 0,
    });

  });
</script>


<!--[if (IE 7)|(IE 8)]><style type= text/css>.fav-control-thumbs li {width: 24.99%!important;}</style><![endif]-->

<script type="text/javascript">
  jQuery(window).load(function(){
    jQuery('#slider-13299').favslider({
	   animation: "slide",
	   directionNav: 0,
	   keyboardNav: 1,
	   mousewheel: 0,
	   slideshow: 1,
	   slideshowSpeed: 7000,
	   randomize: 0,
	   animationLoop: 1,
	   pauseOnHover: 0,controlNav: 0,
      start: function(slider){
        jQuery('body').removeClass('loading');
      }
    });
  });
</script> 



	<div id="slider-13299" class="favslider dark-arrows">

		<ul class="favs">

			
		    <li class="fav-slider-main">

            
		    	  
                <img src="ngs/images/slide/1.jpg" alt="" />

            
            
            
            
                <div id="fav-caption" class="visible favalign-center favstyle-default favstyle-bg-dark layout-effect" style="width:; height:;">

                                          <h3 class="favtitle" style="font-family: Open Sans; font-size: ; text-transform: uppercase; padding: ; margin: ;">
                        The Power                      </h3>
                    
                                          <p class="favdescription" style="font-family: Open Sans; font-size: ;">
                        Power of imagination…                      </p>
                    
                    
                      
                      
                </div>

            
            
		    </li>

      
		    <li class="fav-slider-main">

            
		    	  
                <img src="ngs/images/slide/2.jpg" alt="" />

            
            
            
            
                <div id="fav-caption" class="visible favalign-center favstyle-default favstyle-bg-dark layout-effect" style="width:; height:;">

                                          <h3 class="favtitle" style="font-family: Open Sans; font-size: ; text-transform: uppercase; padding: ; margin: ;">
                        Solutions                      </h3>
                    
                                          <p class="favdescription" style="font-family: Open Sans; font-size: ;">
                        Customizable solutions                      </p>
                    
                    
                      
                      
                </div>

            
            
		    </li>

      
		    <li class="fav-slider-main">

            
		    	  
                <img src="ngs/images/slide/3.jpg" alt="" />

            
            
            
            
                <div id="fav-caption" class="visible favalign-center favstyle-default favstyle-bg-dark layout-effect" style="width:; height:;">

                                          <h3 class="favtitle" style="font-family: Open Sans; font-size: ; text-transform: uppercase; padding: ; margin: ;">
                        Excellence                      </h3>
                    
                                          <p class="favdescription" style="font-family: Open Sans; font-size: ;">
                        Excellence through ICT and service innovation                      </p>
                    
                    
                      
                      
                </div>

            
            
		    </li>

      
		    <li class="fav-slider-main">

            
		    	  
                <img src="ngs/images/slide/4.jpg" alt="" />

            
            
            
            
                <div id="fav-caption" class="visible favalign-center favstyle-default favstyle-bg-dark layout-effect" style="width:; height:;">

                                          <h3 class="favtitle" style="font-family: Open Sans; font-size: ; text-transform: uppercase; padding: ; margin: ;">
                        Cooperation                      </h3>
                    
                                          <p class="favdescription" style="font-family: Open Sans; font-size: ;">
                        Cooperation is a part of success                      </p>
                    
                    
                      
                      
                </div>

            
            
		    </li>

      
		    <li class="fav-slider-main">

            
		    	  
                <img src="ngs/images/slide/5.jpg" alt="" />

            
            
            
            
                <div id="fav-caption" class="visible favalign-center favstyle-default favstyle-bg-dark layout-effect" style="width:; height:;">

                                          <h3 class="favtitle" style="font-family: Open Sans; font-size: ; text-transform: uppercase; padding: ; margin: ;">
                        Technology                      </h3>
                    
                                          <p class="favdescription" style="font-family: Open Sans; font-size: ;">
                        Technology Comes Alive                      </p>
                    
                    
                      
                      
                </div>

            
            
		    </li>

      
		</ul>

	</div>


</section>	</div>
</div>
<div class="gap"></div>
</div>
</div></section><section id="sp-users-wrapper" 
                class=" "><div class="container"><div class="row-fluid" id="users">
<div id="sp-promo" class="span12"><div class="module ">	
	<div class="mod-wrapper clearfix">		
				<div class="mod-content clearfix">	
			<div class="mod-inner clearfix">
				

<div class="custom"  >
	<p>&nbsp;</p>
<p style="text-align: justify;"><strong>About us</strong></p>
<p style="text-align: justify;">Next Generation services (Pvt) Ltd. is a company incorporated in Sri Lanka in the year 2015 to provide total solutions for technology requirements. From small beginnings the company has expanded to provide a comprehensive all round services to its clients not only in production, Sales and marketing but also in the consultancy areas.</p>
<p style="text-align: justify;">At Next generation services (NGS), we enable our clients to achieve excellence through information communication technology and service innovation. We always evolving the way the world moves. In modern business world the most effective communication will always make a change in the way we do business. NGS always helps their clients to improve their business using right communication at the right time using the right technology.At NGS, we all are extremely passionate about Create systems and applications for better life style in a synchronized environment. By seamlessly connecting clients and their customers through our services and apps, we make everything convenient and instant accessible, opening up more possibilities for customer convenience which enable more business opportunities for our clients.&nbsp;</p>
<div class="container-lahiru">
<div class="silver-lahiru">
<div class="price-lahiru">Vision</div>
<p>&nbsp;</p>
<h5>Enable ultimate convenience in a collaborative ecosystem</h5>
<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
<div class="gold-lahiru">
<div class="price-lahiru">Values</div>
<p>&nbsp;</p>
<h5>Energetic</h5>
<h5>Cool Green</h5>
<h5>Collaboration</h5>
<h5>Synchronization</h5>
<h5>Work on basics</h5>
</div>
<div class="plat-lahiru">
<div class="price-lahiru">Mission</div>
<p>&nbsp;</p>
<h5>Create systems and applications for better life style in a synchronised environment</h5>
<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
</div>
<p>&nbsp;</p></div>
			</div>
		</div>
	</div>
</div>
<div class="gap"></div>
<div class="module ">	
	<div class="mod-wrapper clearfix">		
				<div class="mod-content clearfix">	
			<div class="mod-inner clearfix">
				

<div class="custom"  >
	<div style="text-align: justify;">
<p>&nbsp; &nbsp; &nbsp; Our vision is to enable ultimate convenience in a collaborative ecosystem. As human beings, we interact with the ecosystems that surround us (and upon which we depend) in numerous and complex ways. At Next Generation Services, we continuously practice collaborative mapping of ecosystem services to enable win-win situations. We strongly believe that the cooperation is a enabling fact of success and willing to make partnerships to drive collaborative ecosystems which cooperation leads to all participants benefiting.</p>
<p>&nbsp; &nbsp; &nbsp;NGS makes a significant contribution to the business world in its role as a value-adding partner to its clients. NGS continues to provide technologies that respond to customers need in increasingly sophisticated, divers and rapidly changing technological fields. We are flexible when it comes to product changes according to customer requirements and products are always designed to be future proof as much as possible using cutting edge technologies. Recognizing the people as the most important element of productivity in any organization; NGS is continuously committed to cultivate leaders of tomorrow by specializing in developing and implementing their own unique cooperate team culture.</p>
</div></div>
			</div>
		</div>
	</div>
</div>
<div class="gap"></div>
</div>
</div></div></section><section id="sp-testimonial-wrapper" 
                class=" "><div class="container"><div class="row-fluid" id="testimonial">
<div id="sp-hiring" class="span12">

<div class="custom"  >
	<p><img src="ngs/images/Home_page/join_us_s.png" alt="join us s" width="160" height="242" style="margin: 50px 200px 0px 0px; float: right;" /></p>
<p>&nbsp;</p>
<h4>Why join with us?</h4>
<p>&nbsp;</p>
<ul>
<li>Improve your business with use of ICT</li>
<li>Expose new income avenues to your business at NO RISK</li>
<li>Differentiation among competitors through service innovation</li>
<li>We always strive for long lasting relationships with our customers</li>
<li>We are flexible when it comes to product and service changes according to your requirements</li>
<li>Flexible to integrate with existing infrastructure or set up our own subscription management platform</li>
<li>Our services are always designed to be future proof as much as possible.</li>
</ul>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p></div>
</div>
</div></div></section><section id="sp-main-body-wrapper" 
                class=" "><div class="container"><div class="row-fluid" id="main-body">
<div id="sp-message-area" class="span12"><section id="sp-component-area-wrapper" 
                class=" "><div class="row-fluid" id="component-area">
<div id="sp-component-area" class="span12"><section id="sp-component-wrapper"><div id="sp-component"><div id="system-message-container">
	</div>


<section class="featured ">

		
				
		<section class="items-leading">
							<div class="leading-1">
					
<article class="post-31 post hentry status-publish category-aboutus">

			
	
		
		
	<section class="entry-content">  

								
		
				
		<section id="about_us">
<p>&nbsp;</p>
<h4>&nbsp;Our Services&nbsp;</h4>
<ul>
<li>Cloud services</li>
<li>Business consultation</li>
<li>System analytics</li>
<li>ICT education</li>
<li>E-Commerce solutions</li>
<li>ICT related implementations and installations</li>
<li>Mobile applications</li>
<li>Closed circuit advertising</li>
<li>Web development and management</li>
<li>Business forecast and predictions</li>
<li>Develop technology strategies</li>
<li>Personal development and personal strategy</li>
<li>Virtualization High availability and disaster recovery</li>
<li>ECM (Enterprise contain management)</li>
<li>BPM(Business process management)</li>
<li>BAM (Business Activity Monitoring) and middleware</li>
</ul>
</section>		
    </section>
	
	<footer class="entry-meta">
	
				
			
				    
				
    </footer>	
	
</article>				</div>
				<div class="clearfix"></div>
									</section>
		
		<div class="clearfix"></div>
		
	
				
		
		
		
		</section></div></section></div>
</div></section></div>
</div></div></section><section id="sp-clients-wrapper" 
                class=" "><div class="container"><div class="row-fluid" id="clients">
<div id="sp-clients" class="span6"><div class="module ">	
	<div class="mod-wrapper clearfix">		
				<div class="mod-content clearfix">	
			<div class="mod-inner clearfix">
				

<div class="custom"  >
	<h4>&nbsp;</h4>
<h4>GPS Tracker</h4>
<p>NGS combines GPS technology and Google Maps into a reliable, scalable and comprehensive fleet management solution, accessible through a user friendly web based interface. A GPS and GPRS combined tracking solution has the ability to track movable assets, people and vehicle fleets from anywhere at any time.The solution will provide administrative portal and smart Mobile application which support all the service features.</p>
<p>&nbsp;</p>
<div id="form-sclogin-submitcreate" class="control-group"><a href="http://universaltrackers.com/" class="btn">Proceed to Site</a></div>
<div class="control-group">&nbsp;</div>
<div class="control-group">&nbsp;</div></div>
			</div>
		</div>
	</div>
</div>
<div class="gap"></div>
</div>

<div id="sp-social" class="span6"><div class="module ">	
	<div class="mod-wrapper clearfix">		
				<div class="mod-content clearfix">	
			<div class="mod-inner clearfix">
				

<div class="custom"  >
	<h4>NGCommunicator</h4>
<p>Communication is a key challenge in any organization</p>
<p>Most effective communication will make a change in the way we do business</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><a href="http://ngsad.cloudapp.net:8080/RemoDisPro/" class="btn">Proceed to Site</a></p></div>
			</div>
		</div>
	</div>
</div>
<div class="gap"></div>
</div>
</div></div></section><section id="sp-bottom-wrapper" 
                class=" "><div class="container"><div class="row-fluid" id="bottom">
<div id="sp-bottom1" class="span4"><div class="module ">	
	<div class="mod-wrapper-flat clearfix">		
					<h3 class="header">			
				<span>Contact Us</span>			</h3>
								<div id="sp_quickcontact125" class="sp_quickcontact">
	<div id="sp_qc_status"></div>
	<form id="sp-quickcontact-form">
		<div class="sp_qc_clr"></div>
		<input type="text" name="name" id="name" onfocus="if (this.value=='Name...') this.value='';" onblur="if (this.value=='') this.value='Name...';" value="Name..." required />
		<div class="sp_qc_clr"></div>
		<input type="email" name="email" id="email" onfocus="if (this.value=='Email...') this.value='';" onblur="if (this.value=='') this.value='Email...';" value="Email..." required />
		<div class="sp_qc_clr"></div>
		<input type="text" name="subject" id="subject" onfocus="if (this.value=='Subject...') this.value='';" onblur="if (this.value=='') this.value='Subject...';" value="Subject..." />
		<div class="sp_qc_clr"></div>
		<textarea name="message" id="message" onfocus="if (this.value=='Message...') this.value='';" onblur="if (this.value=='') this.value='Message...';" cols="" rows="">Message...</textarea>	
		<div class="sp_qc_clr"></div>
					<input type="text" name="sccaptcha" placeholder="3 + 4 = ?" required />
				<div class="sp_qc_clr"></div>
		<input id="sp_qc_submit" class="button" type="submit" value="Send Message" />
		<div class="sp_qc_clr"></div>
	</form>
</div>	</div>
</div>
<div class="gap"></div>
</div>

<div id="sp-bottom2" class="span4"><div class="module ">	
	<div class="mod-wrapper-flat clearfix">		
					<h3 class="header">			
				<span>Address</span>			</h3>
								

<div class="custom"  >
	<div class="row-fluid">
<div class="span8"><address><strong>Next Generation Services.</strong><br />518/2/1 Kandy Road,&nbsp;<br />Pattiya junction,<br />Kelaniya.&nbsp;</address><address>&nbsp;</address><address>Telephone : +94&nbsp;11&nbsp;2 986377<br />Fax: +94&nbsp;11&nbsp; 2 986388</address></div>
</div>
<h3 class="header">Connect With Us</h3>
<div class="row-fluid social">
<div class="span6">
<p><a href="https://www.facebook.com/ngslanka"><i style="" class="icon-facebook "></i> Facebook</a></p>
<p><a href="https://plus.google.com/103463089769284549506/about"><i style="" class="icon-google-plus "></i> Google Plus</a></p>
<p><a href="#"><i style="" class="icon-pinterest "></i> Pinterest</a></p>
</div>
<div class="span6">
<p><a href="#"><i style="" class="icon-linkedin "></i> Linkedin</a></p>
<p><a href="#"><i style="" class="icon-twitter "></i> Twitter</a></p>
<p><a href="https://www.youtube.com/channel/UCfnCTTk6a3avBVpRO60gRHw"><i style="" class="icon-youtube "></i> You Tube</a></p>
<p>&nbsp;</p>
</div>
</div></div>
	</div>
</div>
<div class="gap"></div>
</div>

<div id="sp-bottom3" class="span4"><div class="module ">	
	<div class="mod-wrapper-flat clearfix">		
					<h3 class="header">			
				<span>Map</span>			</h3>
								<div id="cavas_id141" class="bt-googlemaps"></div>
<script type="text/javascript">var config = {mapType				:'roadmap',width					:'300',height					:'350',cavas_id				:"cavas_id141", zoom					:16,zoomControl			:false,scaleControl			:false,panControl				:false,mapTypeControl			:false,streetViewControl		:false,overviewMapControl		:false,draggable		:true,disableDoubleClickZoom		:false,scrollwheel		:true,weather				:0,temperatureUnit		:'f',cloud					:1,mapCenterType			:"coordinate",mapCenterAddress		:"New York, United States",mapCenterCoordinate	:"6.962515, 79.893523",enableStyle			:"0",styleTitle				:"Map",createNewOrDefault		:"applyDefault",enableCustomInfoBox	:"0",boxPosition			:"-120,10",closeBoxMargin			:"-9px",closeBoxImage			:"",url:"http://www.ngslanka.com/ngs/"};var boxStyles = {"background":"#ffffff","opacity":" 0.85","width":" 220px","height":"100px","border":" 1px solid grey","borderRadius":"3px","padding":" 10px","boxShadow":"30px 10px 10px 1px grey"};var markersCode ="W3sibWFya2VyVGl0bGUiOiJOZXh0IEdlbmVyYXRpb24gU2VydmljZXMiLCJtYXJrZXJUeXBlIjoiY29vcmRpbmF0ZSIsIm1hcmtlclZhbHVlIjoiNi45NjExMTMsIDc5Ljg5Mzg1NyIsIm1hcmtlckljb24iOiJpbWFnZXMvTWFwL3BaNEVWLnBuZyIsIm1hcmtlclNoYWRvd0ltYWdlIjoiaW1hZ2VzL01hcC9wWjRFVi5wbmciLCJtYXJrZXJTaG93SW5mb1dpbmRvdyI6IjEiLCJtYXJrZXJJbmZvV2luZG93IjoiTmV4dCBHZW5lcmF0aW9uIFNlcnZpY2VzLlxuIn1d"; var stylesCode ="W10="; initializeMap(config, markersCode, stylesCode, boxStyles);</script>
	</div>
</div>
<div class="gap"></div>
</div>
</div></div></section><footer id="sp-footer-wrapper" 
                class=" "><div class="container"><div class="row-fluid" id="footer">
<div id="sp-footer2" class="span12">

<div class="custom"  >
	<p><a><img src="ngs/images/logo/ngs%20slog.png" alt="" width="260" height="50" border="0" /></a></p></div>
</div>
</div></div></footer>	

		<a class="hidden-desktop btn btn-inverse sp-main-menu-toggler" href="#" data-toggle="collapse" data-target=".nav-collapse">
			<i class="icon-align-justify"></i>
		</a>

		<div class="hidden-desktop sp-mobile-menu nav-collapse collapse">
			<ul class=""><li class="menu-item active first"><a href="index.html" class="menu-item active first" ><span class="menu"><span class="menu-title">Home</span><span class="menu-desc">Next Generation Services </span></span></a></li><li class="menu-item"><a href="#sp-slideshow-wrapper" class="menu-item" ><span class="menu"><span class="menu-title">Home</span></span></a></li><li class="menu-item"><a href="#sp-users-wrapper" class="menu-item" ><span class="menu"><span class="menu-title">About Us</span></span></a></li><li class="menu-item"><a href="#sp-main-body-wrapper" class="menu-item" ><span class="menu"><span class="menu-title">Our Services</span></span></a></li><li class="menu-item"><a href="#sp-testimonial-wrapper" class="menu-item" ><span class="menu"><span class="menu-title">Join Us</span></span></a></li><li class="menu-item"><a href="#sp-bottom-wrapper" class="menu-item" ><span class="menu"><span class="menu-title">Contact</span></span></a></li><li class="menu-item last"><a href="#sp-clients-wrapper" class="menu-item last" ><span class="menu"><span class="menu-title">Login</span></span></a></li></ul>   
		</div>
		        
		</div>
    </body>


</html>