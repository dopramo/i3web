  
jQuery(document).ready(function(){

	if (jQuery('.fav-video').length > 0) { 

		jQuery('.fav-video').fitVids();

	}

});
