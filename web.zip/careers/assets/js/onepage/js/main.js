$(function() {

	

/* ----- Carousels & Sliders ----- */
	
	// default flex parameters
	if($().flexslider) {
		$('.flexslider').flexslider({
			controlNav: true,
			directionalNav: true,
			slideshow: false
		});
	}


});
