
    // carousel demo

!function ($) {

    $('#myCarousel').carousel()
    
}(window.jQuery)

