<?xml version="1.0" encoding="utf-8"?>
<!-- generator="Joomla! - Open Source Content Management" -->
<feed xmlns="http://www.w3.org/2005/Atom"  xml:lang="en-gb">
	<title type="text">Next Generation Services </title>
	<subtitle type="text"></subtitle>
	<link rel="alternate" type="text/html" href="http://www.ngslanka.com"/>
	<id>http://www.ngslanka.com/ngs/index.php</id>
	<updated>2015-10-23T05:49:58+00:00</updated>
	<generator uri="http://joomla.org">Joomla! - Open Source Content Management</generator>
	<link rel="self" type="application/atom+xml" href="http://www.ngslanka.com/ngs/index.php?format=feed&amp;type=atom"/>
	<entry>
		<title>Our Services</title>
		<link rel="alternate" type="text/html" href="http://www.ngslanka.com/ngs/index.php/19-aboutus/31-aboutus"/>
		<published>2015-07-10T10:21:54+00:00</published>
		<updated>2015-07-10T10:21:54+00:00</updated>
		<id>http://www.ngslanka.com/ngs/index.php/19-aboutus/31-aboutus</id>
		<author>
			<name>Super User</name>
			<email>lahiru@asdf.com</email>
		</author>
		<summary type="html">&lt;div class=&quot;feed-description&quot;&gt;&lt;section id=&quot;about_us&quot;&gt;
&lt;p&gt;&amp;nbsp;&lt;/p&gt;
&lt;h4&gt;&amp;nbsp;Our Services&amp;nbsp;&lt;/h4&gt;
&lt;ul&gt;
&lt;li&gt;Cloud services&lt;/li&gt;
&lt;li&gt;Business consultation&lt;/li&gt;
&lt;li&gt;System analytics&lt;/li&gt;
&lt;li&gt;ICT education&lt;/li&gt;
&lt;li&gt;E-Commerce solutions&lt;/li&gt;
&lt;li&gt;ICT related implementations and installations&lt;/li&gt;
&lt;li&gt;Mobile applications&lt;/li&gt;
&lt;li&gt;Closed circuit advertising&lt;/li&gt;
&lt;li&gt;Web development and management&lt;/li&gt;
&lt;li&gt;Business forecast and predictions&lt;/li&gt;
&lt;li&gt;Develop technology strategies&lt;/li&gt;
&lt;li&gt;Personal development and personal strategy&lt;/li&gt;
&lt;li&gt;Virtualization High availability and disaster recovery&lt;/li&gt;
&lt;li&gt;ECM (Enterprise contain management)&lt;/li&gt;
&lt;li&gt;BPM(Business process management)&lt;/li&gt;
&lt;li&gt;BAM (Business Activity Monitoring) and middleware&lt;/li&gt;
&lt;/ul&gt;
&lt;/section&gt;&lt;/div&gt;</summary>
		<content type="html">&lt;div class=&quot;feed-description&quot;&gt;&lt;section id=&quot;about_us&quot;&gt;
&lt;p&gt;&amp;nbsp;&lt;/p&gt;
&lt;h4&gt;&amp;nbsp;Our Services&amp;nbsp;&lt;/h4&gt;
&lt;ul&gt;
&lt;li&gt;Cloud services&lt;/li&gt;
&lt;li&gt;Business consultation&lt;/li&gt;
&lt;li&gt;System analytics&lt;/li&gt;
&lt;li&gt;ICT education&lt;/li&gt;
&lt;li&gt;E-Commerce solutions&lt;/li&gt;
&lt;li&gt;ICT related implementations and installations&lt;/li&gt;
&lt;li&gt;Mobile applications&lt;/li&gt;
&lt;li&gt;Closed circuit advertising&lt;/li&gt;
&lt;li&gt;Web development and management&lt;/li&gt;
&lt;li&gt;Business forecast and predictions&lt;/li&gt;
&lt;li&gt;Develop technology strategies&lt;/li&gt;
&lt;li&gt;Personal development and personal strategy&lt;/li&gt;
&lt;li&gt;Virtualization High availability and disaster recovery&lt;/li&gt;
&lt;li&gt;ECM (Enterprise contain management)&lt;/li&gt;
&lt;li&gt;BPM(Business process management)&lt;/li&gt;
&lt;li&gt;BAM (Business Activity Monitoring) and middleware&lt;/li&gt;
&lt;/ul&gt;
&lt;/section&gt;&lt;/div&gt;</content>
		<category term="Featured" />
		<category term="About Us" />
	</entry>
</feed>
