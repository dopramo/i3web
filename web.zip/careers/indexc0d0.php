<?xml version="1.0" encoding="utf-8"?>
<!-- generator="Joomla! - Open Source Content Management" -->
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
	<channel>
		<title>Next Generation Services </title>
		<description><![CDATA[]]></description>
		<link>http://www.ngslanka.com/ngs/index.php</link>
		<lastBuildDate>Fri, 23 Oct 2015 05:49:57 +0000</lastBuildDate>
		<generator>Joomla! - Open Source Content Management</generator>
		<atom:link rel="self" type="application/rss+xml" href="http://www.ngslanka.com/ngs/index.php?format=feed&amp;type=rss"/>
		<language>en-gb</language>
		<item>
			<title>Our Services</title>
			<link>http://www.ngslanka.com/ngs/index.php/19-aboutus/31-aboutus</link>
			<guid isPermaLink="true">http://www.ngslanka.com/ngs/index.php/19-aboutus/31-aboutus</guid>
			<description><![CDATA[<div class="feed-description"><section id="about_us">
<p>&nbsp;</p>
<h4>&nbsp;Our Services&nbsp;</h4>
<ul>
<li>Cloud services</li>
<li>Business consultation</li>
<li>System analytics</li>
<li>ICT education</li>
<li>E-Commerce solutions</li>
<li>ICT related implementations and installations</li>
<li>Mobile applications</li>
<li>Closed circuit advertising</li>
<li>Web development and management</li>
<li>Business forecast and predictions</li>
<li>Develop technology strategies</li>
<li>Personal development and personal strategy</li>
<li>Virtualization High availability and disaster recovery</li>
<li>ECM (Enterprise contain management)</li>
<li>BPM(Business process management)</li>
<li>BAM (Business Activity Monitoring) and middleware</li>
</ul>
</section></div>]]></description>
			<author>lahiru@asdf.com (Super User)</author>
			<category>Featured</category>
			<category>About Us</category>
			<pubDate>Fri, 10 Jul 2015 10:21:54 +0000</pubDate>
		</item>
	</channel>
</rss>
