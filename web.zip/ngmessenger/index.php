<?php
header("location: http://220.247.201.100/ngmessenger/login.php");
?>