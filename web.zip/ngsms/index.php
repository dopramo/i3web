<?php
header("location: http://220.247.201.100/ngsms/login.php");
?>